// Create and start a ReadWriteData object.
import javax.swing.JFrame;

public class ReadWriteDataTest
{
	public static void main(String[] args)
	{
		ReadWriteData application = new ReadWriteData();
		application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	} 
}